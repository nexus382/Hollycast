// Portions Copyright 2026 The Hollycast Authors
// Original effect: public domain. This version removes ReShade framework dependencies.

uniform float ScanlineIntensity <
	ui_label = "Scanline Intensity";
	ui_min = 0.0;
	ui_max = 1.0;
	ui_step = 0.05;
> = 0.55;

uniform float ScanlineFrequency <
	ui_label = "Scanline Frequency";
	ui_min = 0.25;
	ui_max = 3.0;
	ui_step = 0.05;
> = 1.0;

texture2D SourceTex < source = "color"; > { Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; };
sampler2D SourceSampler { Texture = SourceTex; Filter = MIN_MAG_MIP_LINEAR; };

float4 MainPS(float4 position : SV_POSITION, float2 texcoord : TEXCOORD0) : SV_Target
{
	float4 color = tex2D(SourceSampler, texcoord);
	float phase = texcoord.y * SourceSize.y * ScanlineFrequency;
	float mask = 1.0 - ScanlineIntensity * (0.5 + 0.5 * sin(phase * 3.14159265));
	return float4(color.rgb * mask, color.a);
}

technique ScanlinesAbs
{
	pass
	{
		PixelShader = MainPS;
	}
}
